module.exports = {
    presets: [['@vue/app', { absoluteRuntime: false }]]
};
