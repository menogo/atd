module.exports = file => () => import('@/pages/' + file + '.vue');
